const {store} = require('../Config/Store');

const GetAllConnection = () =>
{
    return store.get('connection');
}


const SetConnection = (_ConnectionName,_url) =>
{

    try{
    var obj = { id:Math.floor(Math.random() * 1000) + 1, ConnectionName:_ConnectionName, url : _url }

    const connection = store.get('connection');
    const newconnection = [...(connection || []), obj];

    store.set('connection',newconnection);
    }
    catch(e){}
    return true;
}

const GetPinpadSetting = () =>
{
    return store.get('pinpad');
}

const RemoveConnection = (ConnectionName) =>
{
    return true;
}

const SetPinPad = (PinPadIp,PinPadPort,SerialNumber) =>
{
    
    store.set('pinpad',
    {
        "PinPadIp":PinPadIp,
        "PinPadPort":PinPadPort,
        "SerialNumber":SerialNumber
    });

    return true;
}

const SaveConnectionFile =(data)=>
{
    return true;
}

const ReadConnectionFile =()=>{
    let data = {}
   
    return data;
}

module.exports ={
    GetAllConnection,
    GetPinpadSetting,
    SetConnection,
    RemoveConnection,
    SetPinPad,
    ReadConnectionFile
}

