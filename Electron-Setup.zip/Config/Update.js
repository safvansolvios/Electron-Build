const {autoUpdater} = require('electron-updater');
const {dialog } = require('electron');

autoUpdater.logger = require('electron-log');
autoUpdater.logger.info();
autoUpdater.autoDownload = false;

module.exports = (win) =>{
    console.log(win);
    autoUpdater.checkForUpdates();

    autoUpdater.on('update-available',()=>
    {

        dialog.showMessageBox({
            type:"info",
            title:'Update Available',
            message:'A new Version of Botiga is available. Do you want to update now?',
            buttons:['Update','No']
        }).then(res=>{
            let btnindex = res.response;

            if(btnindex === 0) autoUpdater.downloadUpdate()
        })

    });

    autoUpdater.on('update-downloaded',()=>{
        dialog.showMessageBox({
            type:"info",
            title:'Update Ready',
            message:'Install & Restart Now?',
            buttons:['Yes','Later']
        }).then(res=>{
            let btnindex = res.response;

            if(btnindex === 0) autoUpdater.quitAndInstall(false,true);
        })
    });

    autoUpdater.on('download-progress', (progressObj) => {
        let log_message = "Download speed: " + progressObj.bytesPerSecond;
        log_message = log_message + ' - Downloaded ' + progressObj.percent + '%';
        log_message = log_message + ' (' + progressObj.transferred + "/" + progressObj.total + ')';
        win.webContents.send('UpdateProgress', log_message);
    });

}

