
electron-builder create-self-signed-cert -p 77Z